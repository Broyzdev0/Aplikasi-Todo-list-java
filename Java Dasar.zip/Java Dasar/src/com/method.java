package com;

public class method {
    public static void main(String[] args) {
        sayHelloworld(); //unntuk memanggil kode yang di bawah
        sayHelloworld();//unntuk memanggil kode yang di bawah
        
    }

    static void sayHelloworld(){
        System.out.println("Hello world1");
        System.out.println("Hello world2");
        System.out.println("Hello world3");
    }
    
}
