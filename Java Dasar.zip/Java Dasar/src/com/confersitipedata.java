package com;

class confersi {
    
    //note untuk ke bawah (setiap variabel manapun yang di panggil maka akan keluar variabel yang terdapat value)
    byte inibyte = 10;
    short inishort = inibyte;
    int iniint = inishort;

    //note untuk keatas (setiap variabel manapun yang di panggil maka akan keluar variabel yang terdapat value)
    int intint2 = 1000;
    byte inibyte2 = (byte)  intint2;
}

public class confersitipedata {

    public static void main(String[] args){
        confersi confersi1 = new confersi();
        System.out.println(confersi1.iniint);
        System.out.println(confersi1.intint2);
    
 }
}
