package com;

public class forloop {
    public static void main(String[] args) {
        //perulangan terus menerus
       // for (;;){
           // System.out.println("perulangan");
        //}
    
        
        //ditentukan berapa jumlah perulangan yang di buat
         for (var counter = 1; counter <= 10; counter++){
            System.out.println("perulangan" + counter);
         }
    }
    
}
