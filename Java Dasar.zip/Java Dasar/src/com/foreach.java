package com;

public class foreach {
    public static void main(String[] args) {
        String[] names = {
            "eko", "kurniawan", "syahrul",
            "angga", "Adit", "heiwa"

        };
        for (var i = 0; i < names.length; i++){
            System.out.println(names[i]);
        }
        System.out.println("For Each");

        //mengambil data satu satu lebih simpel dari yang atas
        for(var name: names){
            System.out.println(name);
        }

    }
    
}
