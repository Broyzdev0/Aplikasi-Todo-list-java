package com;

public class oprasiboolean {
    public static void main(String[] args) {
        var absen = 70;
        var nilaiakhir = 80;

        boolean lulusabsen = absen >= 75;
        boolean lulusnilai = nilaiakhir >= 75;

        var lulus = lulusabsen && lulusnilai;
        System.out.println(lulus);
    }
    
}
