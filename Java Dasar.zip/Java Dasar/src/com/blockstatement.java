package com;
public class blockstatement{

 public static void main(String[] args) {

    System.out.println("hello word1");//statement
    System.out.println("hello word2");//statement
    System.out.println("hello word3");//statement
 { //ini adalah block pembuka
    System.out.println("hello word1");//statement
    System.out.println("hello word2");//statement
    System.out.println("hello word3");//statement
} //ini adalah block penutup
    
 }
}


//block {} untuk mengrupkan kode
//statement isi dalam block