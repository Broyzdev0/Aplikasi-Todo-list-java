package com;

public class perbandingan {
    public static void main(String[] args) {
int a = 100;
int b = 100;
System.out.println("true = Benar , false = salah");
System.out.println(a > b); //lebih dari
System.out.println(a < b); //kurang dari
System.out.println(a >= b); //lebih dari sama dengan
System.out.println(a <= b);//kurang dari sama dengan
System.out.println(a == b); //sama dengan
System.out.println(a != b); //tidak sama dengan
    }
}
