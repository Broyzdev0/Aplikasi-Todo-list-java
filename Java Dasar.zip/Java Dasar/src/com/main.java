package com;

// membuat class sebagai template
class Mahasiswa{
    String nama;
    String nim;
    String jurusan;
}

public class main {
    public static void main(String[] args) {
        
    
        
        Mahasiswa mahasiswa1 = new Mahasiswa();
        mahasiswa1.nama = "ucup";
        mahasiswa1.nim = "89023";
        mahasiswa1.jurusan = "akuntansi";
        

        System.out.println(mahasiswa1.nama);
        System.out.println(mahasiswa1.nim);
        System.out.println(mahasiswa1.jurusan);
    }
    
}
