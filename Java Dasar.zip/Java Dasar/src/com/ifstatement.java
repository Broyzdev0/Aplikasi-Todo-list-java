package com;

public class ifstatement {

    public static void main(String[] args) {
        var nilai = 90;
        var absen = 10;

        if (nilai >= 90 && absen >= 90) {
            System.out.println("Nilai Anda A");
        } else if (nilai >= 80 && absen >= 80) {
           System.out.println("Nilai anda B"); 
        }else if (nilai >= 70 && absen >= 70) {
            System.out.println("Nilai anda C");
        }else if (nilai >= 60 && absen >= 60) {
            System.out.println("Nilai Anda E");
        }else{
            System.out.println("Maaf Anda Gagal");
        }
    }
}