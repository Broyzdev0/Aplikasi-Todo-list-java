package com;


public class TipeDataArray {
    public static void main(String[] args) {
        //aray -> menampung data sesuai yang diinginkan
    String[] stringArray;
    stringArray = new String[3];
    stringArray [0] = "Broyz";
    stringArray [1] = "syahrul";
    stringArray [2] = "heiwa";

    System.out.println(stringArray[0]);
    System.out.println(stringArray[1]);
    System.out.println(stringArray[2]);

    String[] Namanama = {
        "eko", "kurniawan", "khannedy"
    };
    System.out.println(Namanama[0]);
 
    //Array Initializer
    int[] arrayint = new int[]{
        1, 2, 3, 4, 5, 6, 7, 8,
    };
    System.out.println(arrayint[1]);


    long[] arraylong = new long[]{
        10L, 20L, 30L
    };

    arraylong[0] = 100; //untuk mengubah/menghapus (jika hapus maka 0 = 0;) data tergantung variabel yang di masukan
    System.out.println(arraylong[1]);
    System.out.println(arraylong.length); //melihat panjang araynya berapa
    
    //Array Dalam Array
    String[][] members = {
        {"Heiwa", "adit", "angga"}, //baris array [0]
        {"syahrul", "Dinda"},//baris array [1]
        {"amel"}//baris array [2]
    };

    //aksesnya
    System.out.println(members[0][1]);//[0] baris array [1] isi dalam aray
    System.out.println(members[1][0]);//[0] baris array [1] isi dalam aray

    }
}
