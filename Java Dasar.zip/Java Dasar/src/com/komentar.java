package com;

public class komentar {
    public static void main(String[] args) {

        System.out.println("Untuk banyak komentar (/* */)");
        /*untuk banyak yang ingin di komentar
         * 
         * 
         * 
         * 
         */

         System.out.println("Untuk singgle memakai //");

         //ini untuk tiap baris  (//)
    }
    
}
