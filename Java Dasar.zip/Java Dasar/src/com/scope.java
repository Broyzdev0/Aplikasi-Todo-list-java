package com;

public class scope {

    public static void main(String[] args) {
        sayHello("Eko");
        sayHello( "");
    }
    
    static void sayHello(String name){
        String hello = "HEllo" + name ;

        if(!name.isBlank()){
            String hi = "Hi " + name;
            System.out.println(hi);
        }

        System.out.println(hello);
    }
}

