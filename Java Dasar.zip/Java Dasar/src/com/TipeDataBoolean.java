package com;

class bolean{
    boolean benar = true;
    boolean salah = false;

}
public class TipeDataBoolean {
     public static void main(String[] args) {

        
     }
}
