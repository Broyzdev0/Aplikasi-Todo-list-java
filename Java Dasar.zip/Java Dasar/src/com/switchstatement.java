package com;

public class switchstatement {
    public static void main(String[] args) {
        var nilai = "f";
        var absen = "q";
        //Switch Statement
        System.out.println("Switch Statement");
        switch(nilai){
         case "A":
         System.out.println("Anda Lulus Dengan Baik");
         break;

         case "B":
         case "c":
         System.out.println("Nilai Cukup Baik");
         break;

         case "D":
         System.out.println("Tidak Lulus");
         break;
         default:
         System.out.println("Mungkin Anda Salah Jurusan");
        }

        System.out.println();
        
        //Switch Lambda
        System.out.println("Switch Lambda");


        switch(absen){

            case "A" -> System.out.println("Rajin");
            case "B","C" -> System.out.println("KURANG");
            case "D" -> System.out.println("MALAS");

        default ->{
            System.out.println("Anda di keluarkan wkwkwwk");
        }
        }

       String ucapan;
        switch(nilai){

            case "A" -> ucapan = "Anda sangat sopan";
            case "B","C" -> ucapan = "Anda sangat BAIK";
            case "D" -> ucapan = "Anda sangat Tidak sopan";
        default -> {
            ucapan = "Anda sangat durhaka";
        }
        }
        System.out.println(ucapan);
        
    }
}
