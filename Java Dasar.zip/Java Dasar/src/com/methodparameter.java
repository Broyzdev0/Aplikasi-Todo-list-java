package com;
public class methodparameter {
    public static void main(String[] args) {
        sayHello("eko", "kurniawan");
        sayHello("Budi", "Nugraha");
        sayHello("joko", "nugroho");
    }

    static void sayHello(String firstName, String LastName){
        System.out.println("Hello" + firstName + " " + LastName);
    }

    
}