package com;

public class continuebreak {
    public static void main(String[] args) {
        //untuk break maka apapun yang terjadi program akan berhenti dan melanjutkan ke program berhenti
        /** var counter = 1;
         while(true){
            System.out.println("perulangan ke-1" + counter);
            counter++;

            if(counter > 10){
                break;
            }
         }
         System.out.println("Perulangan berhenti");*/




         //perulangan akan sampai seratus dan lanjut ke perulangan berikutnya
         for (var counter = 1; counter <= 100; counter++){
            if (counter % 2 ==1){
                continue;
            }
            System.out.println("perulangan" + counter);
         }
    }
    
}
