package com;

class contoh {
    String firtsname = "Angga Nur Gunawan";
    String lastname = "Angga";
    String fullname = " nama Panjang " +firtsname + " panggilan " + lastname; //untuk menggabung kan String tinggal menambahkan " " +
}

public class TipeDataString {

    public static void main(String[] args) {
        
        contoh nama = new contoh();
        System.out.println(nama.firtsname);
        System.out.println(nama.lastname);
        System.out.println(nama.fullname);
    }
    

}
