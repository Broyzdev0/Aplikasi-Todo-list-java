package com;

public class whileloop {
    public static void main(String[] args) {
         
        var counter = 0;
                //jika counter lebih dari yang di tentukan di bawah 10 maka 
                //program tidak akan berjalan karena limit 10
        while (counter <= 10){
            System.out.println("perulangan" + counter);

            counter++;
        }
    }
    
}
