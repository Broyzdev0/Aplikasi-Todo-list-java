package com;
public class methodreturnvalue {

    public static void main(String[] args) {
        
        
        
    }
    static int sum(int value1, int value2){
        var total = value1 + value2;
        return total;
    }
}    
 