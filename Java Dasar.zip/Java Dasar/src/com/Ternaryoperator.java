package com;

public class Ternaryoperator {

    public static void main(String[] args) {
        var nilai = 70;
        String ucapan = nilai >= 75 ? "Selamat Anda Lulus" : "Anda Gagal";

        System.out.println(ucapan);
    }

    
}
