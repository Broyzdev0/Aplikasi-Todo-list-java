package com;

public class matematika {
    public static void main(String[] args) {
        System.out.println("operasi matematika");
        //operasi matematika
        int a = 10;
        int b = 20;

        System.out.println(a+b); //tambah +
        System.out.println(b-a);//kurang -
        System.out.println(b/a);//bagi /
        System.out.println(a*b);//kali *
        System.out.println(a%b);//sisa bagi %
System.out.println();

System.out.println("augmented assignments");
        //augmented assignments
        int c = 100;

        c += 10;
        System.out.println(c);

        c -= 10;
        System.out.println(c);
        c *= 10;
        System.out.println(c);
        c /= 10;
        System.out.println(c);
        c %= 10;
        System.out.println(c);
System.out.println();

System.out.println("unary operator");
// unary operator
int d = 100;

d++;
System.out.println(d);

d--;
System.out.println(d);

        
    }
   
}