package com;

class kodeintegernumber{
     //kode integer number
     byte inibyte = 100;
     short inishort = 1000;
     int iniint = 1000000;
     long inilong = 1000000000;
     long inilong2 = 1000000000l; //terdapat variabel L pada akhir angka

}
//flotingdouble
class flotingpointnumber{
    float inifloat = 10.10f;
    double inidouble = 10.10;

}
//code literal
class codeliteral{
    int decimalint = 34;
    int hexadecimal = 0xfffff; //note awalan harus memakai 0
    int binaryDecimal = 0b1010101010; //note awalan harus memakai 0
}

class kodeunderscore{ //agar bisa memakai _
    int amount = 1_000_000_000;
    int sum = 60_000_000;
}

public class TipeDataNumber {
    
public static void main(String[] args)
{
 //integer number
    kodeintegernumber integer = new kodeintegernumber();
    System.out.println(integer.inibyte);
    System.out.println(integer.inishort);
    System.out.println(integer.iniint);
    System.out.println(integer.inilong);
    System.out.println(integer.inilong2);

    System.out.println();

//flotingdouble
    flotingpointnumber flotingdouble = new flotingpointnumber();
    System.out.println(flotingdouble.inifloat);
    System.out.println(flotingdouble.inidouble);

//code literal
    codeliteral literal = new codeliteral();
    System.out.println(literal.decimalint);
    System.out.println(literal.binaryDecimal);
    System.out.println(literal.hexadecimal);
    
//kode underscore _
    kodeunderscore underscore = new kodeunderscore();
    System.out.println(underscore.amount);
    System.out.println(underscore.sum);
    


    

}
    
}
