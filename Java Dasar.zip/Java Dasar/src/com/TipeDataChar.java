package com;

class char1 {

//note kalo char memakai kutip satu ''
    char a = 'a' ;
    char n = 'n' ;
    char g = 'g' ;
    char g1 = 'g' ;
    char a1 = 'a' ;
}

public class TipeDataChar {
    
    public static void name(String[] args) {

        char1 manggilchar = new char1();
        System.out.println(manggilchar.a);
        System.out.println(manggilchar.n);
        System.out.println(manggilchar.g);
        System.out.println(manggilchar.g1);
        System.out.println(manggilchar.a1);
        
    }
    
}
