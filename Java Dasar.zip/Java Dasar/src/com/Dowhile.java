package com;

public class Dowhile {
    public static void main(String[] args) {
        var counter = 100;

       do{
        System.out.println("perulangan" + counter);
        counter++;
       }while (counter <= 10);
    }
}
